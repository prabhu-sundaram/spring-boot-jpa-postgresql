package com.dm.springbootjpapostgresql.model;

public record Greeting(long id, String content) {
    
}
